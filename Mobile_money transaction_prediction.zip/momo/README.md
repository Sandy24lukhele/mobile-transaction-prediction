# Mobile Money Transaction Prediction System

## Setup

1. Clone this repo or unzip the project.
2. Install dependencies:

```bash
pip install -r requirements.txt